#!/bin/bash

# Script to generate a-Linux bootdisk
#
# Copyright (C) 2001	Karsten Scheibler <karsten.scheibler@bigfoot.de>
# Copyright (C) 2002	Konstantin Boldyshev <konst@linuxassembly.org>
#
# $Id: bootdisk.bash,v 1.1 2002/08/17 08:47:47 konst Exp $

TMP_DIR=/tmp/bootdisk-$$
LOG_FILE="$TMP_DIR"/cmdlog
MOUNT_POINT="$TMP_DIR"/mnt
BOOTDISK_IMAGE="$TMP_DIR"/bootdisk
ROOT_IMAGE="$TMP_DIR"/rootraw
ROOT_IMAGE_SIZE=1024

function echo2
	{
	echo "$1" 1>&2 | cat >/dev/null
	}

function echo2n
	{
	echo -n "$1" 1>&2 | cat >/dev/null
	}

function error
	{
	echo2 "$1"
	exit 1
	}

function check
	{
	eval $@ 2>"$LOG_FILE"
	if [ $? -ne 0 ]; then
		echo2 "error"
		sed -e 's/^/    /' "$LOG_FILE" 1>&2 | cat >/dev/null
		exit 1
	else
		echo2 "ok"
	fi
	}

function check2
	{
	eval $@ >"$LOG_FILE" 2>&1
	if [ $? -ne 0 ]; then
		echo2 "error"
		sed -e 's/^/    /' "$LOG_FILE" 1>&2 | cat >/dev/null
		exit 1
	else
		echo2 "ok"
	fi
	}

if [ `id -u` -ne 0 -o `uname` != "Linux" ]; then
	error "this script must be run as root under Linux"
fi

if [ $# -ne 3 ]; then
	echo2 "Usage: $0 kernelfile path_to_asmutils_binaries path_to_rootfs"
	echo2
	echo2 "Given kernel must support ramdisk, minix fs and floppy drive."
	error "Resulting bootdisk is written to stdout."
fi

KERNEL_FILE="$1"
ASMUTILS_PATH="$2"
ROOT_PATH="$3"

trap 'umount "$ROOT_IMAGE" >/dev/null 2>&1; rm -rf "$TMP_DIR"' 0

if ! mkdir "$TMP_DIR" 2>/dev/null; then
	error "can't create '$TMP_DIR'"
fi

echo2n "creating root image mount point ... "
check2 'mkdir -m 755 "$MOUNT_POINT"'

echo2n "creating root image ... "
check2 'dd if=/dev/zero of="$ROOT_IMAGE" bs=1k count="$ROOT_IMAGE_SIZE"'

echo2n "creating root filesystem ... "
check2 'echo y | mkfs.minix "$ROOT_IMAGE"'

echo2n "mounting root image ... "
check2 'mount -o loop -t minix "$ROOT_IMAGE" "$MOUNT_POINT"'

echo2n "copying data to root filesystem ... "
check2 'cp -a $ROOT_PATH/* $MOUNT_POINT &&
  ( cd "$ASMUTILS_PATH"; ls -1 | while read FILE; do if [ -x "$FILE" ]; then
  cp -a "$FILE" "$MOUNT_POINT"/bin/; fi; done;
  chown root.root -R "$MOUNT_POINT"; chmod 555 "$MOUNT_POINT"/bin/* )'

echo2n "copying kernel ... "
check2 'dd if="$KERNEL_FILE" of="$BOOTDISK_IMAGE" bs=1024'

echo2n "umounting root image ... "
check2 'umount "$ROOT_IMAGE"'

echo2n "compressing root image ... "
check2 'gzip -9 "$ROOT_IMAGE"'

set `ls -li $BOOTDISK_IMAGE`
let KERNEL_SIZE=$6/1024+1
echo2 "Kernelsize: $KERNEL_SIZE KB"

let RAMDISK_WORD=$KERNEL_SIZE+16384
echo2 "Ramdisk Flags: $RAMDISK_WORD"

set `ls -li $ROOT_IMAGE.gz`
let COMPRESSED_ROOT_IMAGE_SIZE=$6/1024+1
echo2 "compressed root image size: $COMPRESSED_ROOT_IMAGE_SIZE KB"

let ROOT_AND_KERNEL=$COMPRESSED_ROOT_IMAGE_SIZE+$KERNEL_SIZE
echo2 "compressed root image + kernel: $ROOT_AND_KERNEL KB"

if [ "$ROOT_AND_KERNEL" -le 1440 ]; then 
	echo2 "disk image fits on 1.44MB floppy disk ;-)"
else
	error "disk image is too large for a 1.44MB floppy disk ;-O"
fi

echo2n "setting kernel root device ... "
check2 'rdev "$BOOTDISK_IMAGE" /dev/fd0'

echo2n "setting kernel root filesystem to rw ... "
check2 'rdev -R "$BOOTDISK_IMAGE" 0'

echo2n "setting kernel ramdisk word ... "
check2 'rdev -r "$BOOTDISK_IMAGE" "$RAMDISK_WORD"'

echo2n "setting kernel video mode ... "
check2 'rdev -v "$BOOTDISK_IMAGE" 768'

echo2n "appending root filesystem to kernel ... "
check2 'dd if="$ROOT_IMAGE".gz of="$BOOTDISK_IMAGE" bs=1024 seek="$KERNEL_SIZE"'

echo2n "outputting bootdisk ... "
check 'cat "$BOOTDISK_IMAGE"'
